#ifndef _BLAST_TOOLKIT__H
#define _BLAST_TOOLKIT__H

/** @file blast_toolkit.h
 * Choose C++ basic defines
 */

#include <corelib/ncbitype.h>

#endif
